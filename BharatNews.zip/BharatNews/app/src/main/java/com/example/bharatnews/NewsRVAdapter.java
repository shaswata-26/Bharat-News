package com.example.bharatnews;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class NewsRVAdapter extends RecyclerView.Adapter<NewsRVAdapter.VeiwHolder> {
    private ArrayList<Article>articleArrayList;
    private Context context;

    public NewsRVAdapter(ArrayList<Article> articleArrayList, Context context) {
        this.articleArrayList = articleArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public NewsRVAdapter.VeiwHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.news_rv_item,parent,false);
        return new NewsRVAdapter.VeiwHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull NewsRVAdapter.VeiwHolder holder, int position) {
          Article articles=articleArrayList.get(position);
          holder.subTitleTV.setText(articles.getDescription());
          holder.titleTV.setText(articles.getDescription());
          Picasso.get().load(articles.getUrlToImage()).into(holder.newsIv);
          holder.itemView.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View view) {
                  Intent i=new Intent(context,NewsDeactivity.class);
                  i.putExtra("title",articles.getTitle());
                  i.putExtra("content",articles.getContent());
                  i.putExtra("desc",articles.getDescription());
                  i.putExtra("image",articles.getUrlToImage());
                  i.putExtra("url",articles.getUrl());
                  context.startActivity(i);
              }
          });


    }

    @Override
    public int getItemCount() {
        return articleArrayList.size();
    }

    public class VeiwHolder extends RecyclerView.ViewHolder{
        private TextView titleTV,subTitleTV;
        private ImageView newsIv;
        public VeiwHolder(@NonNull View itemView) {
            super(itemView);
            titleTV=itemView.findViewById(R.id.idTVNewsHeading);
            subTitleTV=itemView.findViewById(R.id.idTVSubTitle);
            newsIv=itemView.findViewById(R.id.idIVNews);
        }
    }
}
